#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "dynamicArray.h"


int in_stack( DynArr * s,char tofind);
int valid_bracket(char * str);

